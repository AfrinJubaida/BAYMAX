/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baymax;
import java.sql.*;
import java.net.*;

/**
 *
 * @author Hp
 */
public class Baymax {

    /**
     * @param args the command line arguments
     */
        public static void main(String[] args){
            
        String name="anika",password1="password",gender="female";
        int age=17,cur_weight=60,des_weight=50,bodypart=1;
        Connection conn = null;
 try{
  String driverName = "oracle.jdbc.driver.OracleDriver";
  Class.forName(driverName);
  String serverName = "localhost";
  String serverPort = "1521";
  String sid = "orcl";
  String url = "jdbc:oracle:thin:@" + serverName + ":" + serverPort + ":"+ sid;
  String username = "baymax";
  String password = "baymax"; 
  conn = DriverManager.getConnection(url, username, password);
  System.out.println("Success");
 } catch (Exception e){
  System.out.println("couldn't find data base" + e.getMessage());
 } 
try{
CallableStatement stmt=conn.prepareCall("{?=call Insertcustomer (?,?,?,?,?,?,?)}");  
stmt.setString(2,name);
stmt.setString(3,password1);
stmt.setInt(4,age);  
stmt.setString(5,gender);
stmt.setInt(6,cur_weight);
stmt.setInt(7,des_weight);
stmt.setInt(8,bodypart);
stmt.registerOutParameter(1,Types.VARCHAR);  
stmt.execute();  
  
System.out.println(stmt.getString(1));  
}
catch (Exception e){
  System.out.println("problem" + e.getMessage());
 } 
    } 
    
}
